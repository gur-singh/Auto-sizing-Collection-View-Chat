module.exports = function(application) {

    application.post('/socketQRCode', function(req, res){
      console.log("\n[ROUTE]: [post] /socketQRCode");
      // Recupera informacoes do formulario
      var dadosForm = req.body;
      // Separa as informações necessarias
      var message = dadosForm.message;
      var qrCode = dadosForm.qrCode;
      // Emite a mensagem
      application.settings.io.to(qrCode).emit('qrCodeMessage', message);
      // Envia uma resposa a requisição
      res.status(200).format({
        json: function() {
          var retorno = {
            "data": "QRCode"
          }
          res.json(retorno);
        }
      });
    });
  
  }
  var io = require('socket.io').listen(server);
 application.set('io', io); 
