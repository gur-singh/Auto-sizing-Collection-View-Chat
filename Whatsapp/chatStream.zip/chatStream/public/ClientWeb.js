var socket = io(window.location.host);

$(document).ready(function() {

  socket.on('connect', function(data){
    console.log("[SOCKET]: Connected");
    $('#socketStatus').text("Connected");
    $('#qrCodeImage').html("");
    $('#qrCodeSocket').text(socket.io.engine.id);
    $('#qrCodeImage').qrcode(socket.io.engine.id);
  });

  socket.on('reconnecting', function(data){
    console.log("[SOCKET]: Reconnecting");
    $('#socketStatus').text("Reconnecting");
    $('#qrCodeImage').html("");
    $('#qrCodeSocket').text("");
  });

  socket.on('disconnect', function(data){
    console.log("[SOCKET]: Disconnect");
    $('#socketStatus').text("Disconnect");
    $('#qrCodeImage').html("");
    $('#qrCodeSocket').text("");
  });

  socket.on('qrCodeMessage', function(data){
    console.log("[SOCKET]: QrCodeMessage");
    $('#qrCodeMessage').text(data);
    $('#qrCodeImage').html("");
    $('#qrCodeImage').append('<img id="qrCodeSuccess" src="/chat.png" alt="QR Code Checked" width="256" height="256">');
    setTimeout(function () {
        $('#qrCodeImage').qrcode(socket.io.engine.id);
        $('#qrCodeSuccess').remove();
    }, 3000);
  });

});